"use client";

import Skeleton from "@/components/ui/skeleton";
import UserCard from "@/components/UserCard";
import { useFetchCats } from "@/hooks/useGetCatList";
import useFetchUsers from "@/hooks/useGetRandomUser";
import { useMemo } from "react";

function Page() {
  const {
    data: catData,
    isFetchingNextPage: isFetchingNextCatPage,
    isLoading: isLoadingCats,
  } = useFetchCats();

  const {
    data: userData,

    isFetchingNextPage: isFetchingNextUserPage,
    isLoading: isLoadingUsers,
  } = useFetchUsers();

  const combinedData = useMemo(() => {
    if (!catData || !userData) return [];
    const allCats = catData.pages.flatMap((page) => page.data);
    const allUsers = userData.pages.flatMap((page) => page.results);
    return allCats.map((cat, index) => ({
      cat,
      user: allUsers[index % allUsers.length],
    }));
  }, [catData, userData]);

  if (isLoadingCats || isLoadingUsers) {
    return (
      <div className="space-y-5 container mx-auto px-4 py-8">
        {Array.from({ length: 5 }).map((_, index) => (
          <Skeleton key={index} />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-5 container mx-auto px-4 py-8">
      {combinedData.map((item, index) => (
        <UserCard
          key={`${item.cat.fact.slice(0, 20)}-${index}`}
          description={item.cat.fact}
          userImage={item.user?.picture?.medium || "/file.svg"}
          userName={
            item.user
              ? `${item.user.name.first} ${item.user.name.last}`
              : "Unknown User"
          }
        />
      ))}

      {isFetchingNextCatPage || isFetchingNextUserPage ? (
        <div className="space-y-5">
          {Array.from({ length: 3 }).map((_, index) => (
            <Skeleton key={`loading-${index}`} />
          ))}
        </div>
      ) : null}
    </div>
  );
}

export default Page;
