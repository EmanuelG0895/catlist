import { useInfiniteQuery } from "@tanstack/react-query";

interface Cat {
  fact: string;
  length: number;
}

export interface CatApiResponse {
  hasMore: unknown;
  current_page: number
  data: Cat[]
  first_page_url: string
  last_page: number
  last_page_url: string
  next_page_url: string | null
  per_page: number
  prev_page_url: string | null
  to: number
  total: number
}

const fetchCatFacts = async ({ pageParam = 1 }): Promise<CatApiResponse> => {
  const response = await fetch(`/services/apiCat?page=${pageParam}`)
  if (!response.ok) {
    throw new Error("Failed to fetch cat facts")
  }
  return response.json()
}

const useFetchCats = () => {
  return useInfiniteQuery({
    queryKey: ["catFacts"],
    queryFn: fetchCatFacts,
    getNextPageParam: (lastPage) => {
      return lastPage.hasMore ? lastPage.current_page + 1 : undefined;
    },
    initialPageParam: 1,
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
};
export { useFetchCats };
