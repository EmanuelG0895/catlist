// src/services/apiCat.ts
import axios from "axios";

export interface Cat {
  fact: string;
  length: number;
}

export interface CatApiResponse {
  current_page: number;
  data: Cat[];
  last_page: number;
  per_page: number;
  total: number;
}

const getCats = async (page = 1, limit = 10): Promise<CatApiResponse> => {
  const response = await axios.get(
    `https://catfact.ninja/facts?page=${page}&limit=${limit}`
  );
  return response.data;
};

export default getCats;
