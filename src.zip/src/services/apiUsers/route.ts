import axios from "axios";
interface UsersApiResponse {
  info: [];
  results: [];
}

const getUsers = async (results = 15): Promise<UsersApiResponse> => {
  const response = await axios.get(
    `https://randomuser.me/api?results=${results}`
  );
  return response.data;
};

export default getUsers;
